import PIXI from 'pixi.js';
import utils  from '../../utils';
import AnimationManager  from './utils/AnimationManager';
export default class Salsichinha extends PIXI.Container{

    constructor() {
    	super();
    	console.log('SALSICHA');

		this.animationContainerBody = new PIXI.Container();
		this.animationContainerHead = new PIXI.Container();
        // this.animationContainer.x = -5
        // this.animationContainer.y = 0
        this.addChild(this.animationContainerBody);
        this.addChild(this.animationContainerHead);

        this.build();
    }
    build(){

    	let enemieType = '';

    	this.animationModelBody = [];
        this.animationModelBody.push({
            label:'runLD',
            src:enemieType+'run/runLD00',
            totalFrames:8,
            startFrame:0,
            animationSpeed:0.4,
            movieClip:null,
            position:{x:0,y:0},
            anchor:{x:0.5,y:1}
        });

        this.animationModelBody.push({
            label:'runL',
            src:enemieType+'run/runL00',
            totalFrames:8,
            startFrame:0,
            animationSpeed:0.4,
            movieClip:null,
            position:{x:6,y:0},
            anchor:{x:0.5,y:1}
        });

        this.animationModelBody.push({
            label:'runLU',
            src:enemieType+'run/runLU00',
            totalFrames:8,
            startFrame:0,
            animationSpeed:0.4,
            movieClip:null,
            position:{x:4,y:0},
            anchor:{x:0.5,y:1}
        });

        this.animationModelBody.push({
            label:'idleLD',
            src:enemieType+'idle/idleLD',
            totalFrames:1,
            startFrame:0,
            animationSpeed:0.4,
            movieClip:null,
            position:{x:0,y:-10},
            anchor:{x:0.5,y:1},
            singleFrame:true,
        });

        this.animationModelBody.push({
            label:'idleL',
            src:enemieType+'idle/idleL',
            totalFrames:1,
            startFrame:0,
            animationSpeed:0.4,
            movieClip:null,
            position:{x:6,y:-10},
            anchor:{x:0.5,y:1},
            singleFrame:true,
        });

        this.animationModelBody.push({
            label:'idleLU',
            src:enemieType+'idle/idleLU',
            totalFrames:1,
            startFrame:0,
            animationSpeed:0.4,
            movieClip:null,
            position:{x:4,y:-10},
            anchor:{x:0.5,y:1},
            singleFrame:true,
        });

        this.animationManagerBody = new AnimationManager(this.animationModelBody, this.animationContainerBody);
        this.animationManagerBody.finishCallback = this.finishAnimation.bind(this);

        this.animationManagerBody.hideAll();
        this.animationManagerBody.stopAll();
        this.animationManagerBody.changeState('runLU');

        this.bodyAnimationList = ['runLU',
'runLD',
'runL',
'runRU',
'runRD',
'runR']

		// this.animationContainerBody.scale.x = -1
		// this.animationContainerBody.x = -5

        this.animationModelHead = [];

        this.animationModelHead.push({
            label:'headU',
            src:enemieType+'head/headU00',
            totalFrames:8,
            startFrame:0,
            animationSpeed:0.4,
            movieClip:null,
            position:{x:0,y:0},
            anchor:{x:0.5,y:1}
        });

        this.animationModelHead.push({
            label:'headLU',
            src:enemieType+'head/headLU00',
            totalFrames:8,
            startFrame:0,
            animationSpeed:0.4,
            movieClip:null,
            position:{x:13,y:0},
            anchor:{x:0.5,y:1}
        });

        this.animationModelHead.push({
            label:'headLD',
            src:enemieType+'head/headLD00',
            totalFrames:8,
            startFrame:0,
            animationSpeed:0.4,
            movieClip:null,
            position:{x:13,y:0},
            anchor:{x:0.5,y:1}
        });

        this.animationModelHead.push({
            label:'headD',
            src:enemieType+'head/headD00',
            totalFrames:8,
            startFrame:0,
            animationSpeed:0.4,
            movieClip:null,
            position:{x:0,y:0},
            anchor:{x:0.5,y:1}
        });

        this.animationModelHead.push({
            label:'headL',
            src:enemieType+'head/headL00',
            totalFrames:8,
            startFrame:0,
            animationSpeed:0.4,
            movieClip:null,
            position:{x:15.5,y:0},
            anchor:{x:0.5,y:1}
        });

        this.animationModelHead.push({
            label:'attackU',
            src:enemieType+'attack/attackU00',
            totalFrames:8,
            startFrame:0,
            animationSpeed:0.4,
            movieClip:null,
            position:{x:-4,y:22},
            anchor:{x:0.5,y:1},
            haveCallback:true,
            loop:false
        });

        this.animationModelHead.push({
            label:'attackLU',
            src:enemieType+'attack/attackLU00',
            totalFrames:8,
            startFrame:0,
            animationSpeed:0.4,
            movieClip:null,
            position:{x:5,y:24},
            anchor:{x:0.5,y:1},
            haveCallback:true,
            loop:false
        });

        this.animationModelHead.push({
            label:'attackLD',
            src:enemieType+'attack/attackLD00',
            totalFrames:8,
            startFrame:0,
            animationSpeed:0.4,
            movieClip:null,
            position:{x:2,y:25},
            anchor:{x:0.5,y:1},
            haveCallback:true,
            loop:false
        });

        this.animationModelHead.push({
            label:'attackD',
            src:enemieType+'attack/attackD00',
            totalFrames:8,
            startFrame:0,
            animationSpeed:0.4,
            movieClip:null,
            position:{x:-4,y:23},
            anchor:{x:0.5,y:1},
            haveCallback:true,
            loop:false
        });

        this.animationModelHead.push({
            label:'attackL',
            src:enemieType+'attack/attackL00',
            totalFrames:8,
            startFrame:0,
            animationSpeed:0.4,
            movieClip:null,
            position:{x:-4,y:25},
            anchor:{x:0.5,y:1},
            haveCallback:true,
            loop:false
        });

        this.animationManagerHead = new AnimationManager(this.animationModelHead, this.animationContainerHead);
        this.animationManagerHead.finishCallback = this.finishAnimationHead.bind(this);

        this.animationManagerHead.hideAll();
        this.animationManagerHead.stopAll();
        this.animationManagerHead.changeState('headD');

        

        // this.animationManagerHead.showJust(['headD','attackU'])

        this.animationContainerHead.y = -105

        this.headAnimationList = ['headU',
'headLU',
'headLD',
'headD',
'headL',
'headRU',
'headRD',
'headR']

		this.headPosition = 'headD';
		this.bodyPosition = 'runLD';

		this.speed = {x:300, y:300}
		this.velocity = {x:0, y:0}

    }

    attack () {
    	// console.log('attack');
    	this.headPosition = 'attack' + this.headAngleType;
    	this.attacking = true;
    	this.updateHead();
    }
    update (delta) {
    	this.x += this.velocity.x * delta;
    	this.y += this.velocity.y * delta;
    	this.animationManagerHead.updateAnimations();
    }
    updateInputs (input) {
    	// console.log(input);
    	this.velocity.x = this.speed.x * input[0];
    	this.velocity.y = this.speed.y * input[1];

    }
    updateBodyPosition () {

    	let angle = Math.atan2(this.velocity.y, this.velocity.x);
    	angle = angle * 180 / 3.14;
    	// console.log(angle, this.y, mousePosition.y);

    	// console.log(Math.abs(this.velocity.y) + Math.abs(this.velocity.x));
    	if(Math.abs(this.velocity.y) + Math.abs(this.velocity.x) == 0){
    		this.stopAnimation();
    		return
    	}
    	if(angle > -160 && angle < -120){
    		this.bodyPosition = 'runLU';
    	}
    	else if(angle > -120 && angle < -60){
    		if(this.velocity.x > 0){
    			this.bodyPosition = 'runLU';
    		}else{
    			this.bodyPosition = 'runRU';
    		}
    	}
    	else if(angle > -60 && angle < -30){
    		this.bodyPosition = 'runRU';
    	}
    	else if(angle > -30 && angle < 30){
    		this.bodyPosition = 'runR';
    	}
    	else if(angle > 30 && angle < 60){
    		this.bodyPosition = 'runRD';
    	}else if(angle < 120 && angle > 60){
    		if(this.velocity.x > 0){
    			this.bodyPosition = 'runLD';
    		}else{
    			this.bodyPosition = 'runRD';
    		}
    	}
    	else if(angle < 160 && angle > 120){
    		this.bodyPosition = 'runLD';
    	}else{
    		this.bodyPosition = 'runL';
    	}

    	// console.log(this.bodyPosition);
    	this.updateLegs();

    }
    stopAnimation () {
    	this.bodyPosition = this.bodyPosition.replace('run', 'idle');
    	this.updateLegs();
    }
    updateHeadAnimation (angle) {

    	// this.headAngleType = 
    	this.animationContainerBody.parent.setChildIndex(this.animationContainerBody, 0);

    	if(angle > -160 && angle < -120){
    		// this.headPosition = 'headLU';
    		this.headAngleType = 'LU';
    		this.animationContainerHead.parent.setChildIndex(this.animationContainerHead, 0);
    	}
    	else if(angle > -120 && angle < -60){
    		// this.headPosition = 'headU';
    		this.headAngleType = 'U';
    		this.animationContainerHead.parent.setChildIndex(this.animationContainerHead, 0);
    	}
    	else if(angle > -60 && angle < -30){
    		// this.headPosition = 'headRU';
    		this.headAngleType = 'RU';
    		this.animationContainerHead.parent.setChildIndex(this.animationContainerHead, 0);

    	}
    	else if(angle > -30 && angle < 30){
    		// this.headPosition = 'headR';
    		this.headAngleType = 'R';
    	}
    	else if(angle > 30 && angle < 60){
    		// this.headPosition = 'headRD';
    		this.headAngleType = 'RD';
    	}else if(angle < 120 && angle > 60){
    		// this.headPosition = 'headD';
    		this.headAngleType = 'D';
    	}
    	else if(angle < 160 && angle > 120){
    		// this.headPosition = 'headLD';
    		this.headAngleType = 'LD';
    	}else{
    		// this.headPosition = 'headL';
    		this.headAngleType = 'L';
    	}

    	this.headPosition = 'head' + this.headAngleType;
    	this.updateHead();

    }
    updateHeadPositionController (mousePosition) {
    	let angle = Math.atan2(mousePosition[1],  mousePosition[0] );
    	angle = angle * 180 / 3.14;
    	
    	this.updateHeadAnimation(angle);
    	
    }
    updateHeadPosition (mousePosition) {
    	let angle = Math.atan2(mousePosition.y - this.y, mousePosition.x - this.x);
    	angle = angle * 180 / 3.14;

    	this.updateHeadAnimation(angle);

    }
    updateHead ( ) {
    	let side = this.headPosition//this.headAnimationList[Math.floor(Math.random() * this.headAnimationList.length)];

    	if(this.animationManagerHead.state.indexOf('attack') !== -1 && this.attacking){

    		return
    	}
    	if(side.indexOf('R') !== -1){
    		this.animationContainerHead.scale.x = -1
        	this.animationContainerHead.x = -5
    	}else{
    		this.animationContainerHead.scale.x = 1
        	this.animationContainerHead.x = 0
    	}
    	side = side.replace('R', 'L');

    	this.animationManagerHead.changeState(side, this.attacking );
    }


    updateLegs ( ) {
    	let side = this.bodyPosition//this.bodyAnimationList[Math.floor(Math.random() * this.bodyAnimationList.length)];

    	// console.log(side);
    	if(side.indexOf('R') !== -1){
    		this.animationContainerBody.scale.x = -1
        	this.animationContainerBody.x = -5
    	}else{
    		this.animationContainerBody.scale.x = 1
        	this.animationContainerBody.x = 0
    	}
    	side = side.replace('R', 'L');
    	this.animationManagerBody.changeState(side);
    }


    endAttack ( ) {
    	this.headPosition = 'head' + this.headAngleType;
        this.attacking = false;
    	this.updateHead();
    }
    finishAnimationHead ( ) {
        if(this.animationManagerHead.state.indexOf('attack') !== -1){
        	this.endAttack();
        }        
    }

    finishAnimation ( ) {
    
        if(this.animationManagerBody.state == 'headLD'){
           
        }        
    }
}